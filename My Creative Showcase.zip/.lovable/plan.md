# Portfólio Jéssica Junker — Plano Atualizado

Página única em português (TanStack Start + Tailwind 4), navegação por âncoras e scroll suave.

## Estrutura de seções

1. **Hero** — nome, cargo (Senior Product Manager), proposta de valor (Fintech × Agritech × IA), CTAs.
2. **Sobre** — trajetória (PwC → Warren → Aegro), formação em Contabilidade, áreas (Reforma Tributária, IA Generativa, Continuous Discovery).
3. **Cases de Produto** (profissionais):
   - Mini-apps de IA para obrigações fiscais
   - Self-checkout PLG
   - Informes de Rendimento
4. **Projetos com IA / Side Projects**:
   - Jogo da velha da Isadora — https://carousel-isadora-tic-tac-toe.lovable.app/
   - Simulador Funrural 2026 — https://jessicajunker-hub.github.io/Simuladorfunrural2026/
   - ERP de Equoterapia (placeholder "em breve")
5. **Cursos & Palestras ministrados**:
   - Minicurso "Do papel ao digital: emissão de NF-e" (Aegro)
   - 3 aulas no YouTube (thumbnails via `img.youtube.com/vi/{id}/hqdefault.jpg`)
   - **3º Bootcamp de Relacionamento da Aegro** — "Reforma Tributária, NFe, MDF-e e o Produtor: O Lado Burocrático do Agro" (2h). Thumbnail: certificado enviado.
   - **7ª SEAGRO — Semana Acadêmica de Agronomia (São Vicente do Sul)** — Palestra sobre Contabilidade do Agronegócio. Thumbnail: foto do palco enviada.
6. **Atuação como Contadora** — cards das demonstrações financeiras assinadas (CVM):
   - Fundo 1 — https://sistemas.cvm.gov.br/docsrecebidos/20200731192912UP56c63e1d5a284e9ba1c86b1576ebf66e.pdf
   - Fundo 2 — https://sistemas.cvm.gov.br/docsrecebidos/20210131215045UP86d82af3d2c14614803c16d13272bcc6.pdf
7. **Skills & Ferramentas** — chips agrupados (Discovery, Delivery, IA, Contábil/Fiscal).
8. **Contato / Rodapé** — e-mail, LinkedIn, GitHub.

## Navegação
Header sticky: Sobre · Cases · Projetos · Cursos · Contábil · Contato. Menu mobile via `Sheet`. Scroll suave.

## Design
Paleta baseada no tema atual (deep blue/slate OKLCH) com accent quente para CTAs. Tipografia sóbria, cards com hover sutil.

## Arquivos
- `src/routes/index.tsx` — compõe as seções.
- `src/components/portfolio/` — `Hero.tsx`, `Sobre.tsx`, `Cases.tsx`, `Projetos.tsx`, `Cursos.tsx`, `Contabil.tsx`, `Skills.tsx`, `Header.tsx`, `Footer.tsx`.
- `src/routes/__root.tsx` — `head()` com título/description/OG reais.
- `src/assets/certificado-aegro-bootcamp.jpeg.asset.json` — pointer do certificado (upload via `lovable-assets`).
- `src/assets/palestra-seagro.jpeg.asset.json` — pointer da foto da palestra na SEAGRO.

Confirma para eu implementar?
